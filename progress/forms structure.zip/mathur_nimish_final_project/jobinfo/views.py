from django.shortcuts import render, get_object_or_404
from django.views import View

from jobinfo.forms import JobRecruiterForm, CompanyForm, JobSeekerForm, PositionForm, AppCycleForm, ApplicationForm
from jobinfo.models import (
    JobRecruiter,
    Company, JobSeeker, Position, AppCycle, Application,
)
from jobinfo.utils import ObjectCreateMixin


class JobRecruiterList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/jobRecruiter_list.html',
                      {'jobRecruiter_list': JobRecruiter.objects.all()}
                      )


class JobRecruiterDetail(View):
    def get(self, request, pk):
        jobRecruiter = get_object_or_404(JobRecruiter, pk=pk)
        company_list = jobRecruiter.companies.all()
        return render(request,
                      'jobinfo/jobRecruiter_detail.html',
                      {'jobRecruiter': jobRecruiter, 'company_list': company_list}
                      )


class JobRecruiterCreate(ObjectCreateMixin, View):
    form_class = JobRecruiterForm
    template_name = 'jobinfo/jobRecruiter_form.html'


class CompanyList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/company_list.html',
                      {'company_list': Company.objects.all()}
                      )


class CompanyDetail(View):
    def get(self, request, pk):
        company = get_object_or_404(Company, pk=pk)
        company_appCycle = company.appCycle
        position = company.position
        jobRecruiter = company.jobRecruiter
        application_list = company.applications.all()
        return render(request,
                      'jobinfo/company_detail.html',
                      {'company': company, 'appCycle': company_appCycle, 'position': position,
                       'jobRecruiter': jobRecruiter,
                       'application_list': application_list}
                      )


class CompanyCreate(ObjectCreateMixin, View):
    form_class = CompanyForm
    template_name = 'jobinfo/company_form.html'


class JobSeekerList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/jobSeeker_list.html',
                      {'jobSeeker_list': JobSeeker.objects.all()}
                      )


class JobSeekerDetail(View):
    def get(self, request, pk):
        jobSeeker = get_object_or_404(JobSeeker, pk=pk)
        application_list = jobSeeker.applications.all()
        return render(request,
                      'jobinfo/jobSeeker_detail.html',
                      {'jobSeeker': jobSeeker, 'application_list': application_list}
                      )


class JobSeekerCreate(ObjectCreateMixin, View):
    form_class = JobSeekerForm
    template_name = 'jobinfo/jobSeeker_form.html'


class PositionList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/position_list.html',
                      {'position_list': Position.objects.all()}
                      )


class PositionDetail(View):
    def get(self, request, pk):
        position = get_object_or_404(Position, pk=pk)
        company_list = position.companies.all()
        return render(request, 'jobinfo/position_detail.html',
                      {'position': position, 'company_list': company_list}
                      )


class PositionCreate(ObjectCreateMixin, View):
    form_class = PositionForm
    template_name = 'jobinfo/position_form.html'


class AppCycleList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/appCycle_list.html',
                      {'appCycle_list': AppCycle.objects.all()}
                      )


class AppCycleDetail(View):
    def get(self, request, pk):
        appCycle = get_object_or_404(AppCycle, pk=pk)
        company_list = appCycle.companies.all()
        return render(request, 'jobinfo/appCycle_detail.html', {'appCycle': appCycle, 'company_list': company_list})


class AppCycleCreate(ObjectCreateMixin, View):
    form_class = AppCycleForm
    template_name = 'jobinfo/appCycle_form.html'


class ApplicationList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/application_list.html',
                      {'application_list': Application.objects.all()}
                      )


class ApplicationDetail(View):
    def get(self, request, pk):
        application = get_object_or_404(Application, pk=pk)
        return render(request, 'jobinfo/application_detail.html',
                      {'application': application, 'jobSeeker': application.jobSeeker, 'company': application.company})


class ApplicationCreate(ObjectCreateMixin, View):
    form_class = ApplicationForm
    template_name = 'jobinfo/application_form.html'
