from django.urls import path

from jobinfo.views import (
    JobRecruiterList,
    CompanyList,
    JobSeekerList,
    PositionList,
    AppCycleList,
    ApplicationList,
)


urlpatterns = [
    path('jobRecruiter/', JobRecruiterList.as_view(),
         name='jobinfo_jobRecruiter_list_urlpattern'),
    path('company/', CompanyList.as_view(),
         name='jobinfo_company_list_urlpattern'),
    path('position/', PositionList.as_view(),
         name='jobinfo_position_list_urlpattern'),
    path('appCycle/', AppCycleList.as_view(),
         name='jobinfo_appCycle_list_urlpattern'),
    path('jobSeeker/', JobSeekerList.as_view(),
         name='jobinfo_jobSeeker_list_urlpattern'),
    path('application/', ApplicationList.as_view(),
             name='jobinfo_application_list_urlpattern'),
]
