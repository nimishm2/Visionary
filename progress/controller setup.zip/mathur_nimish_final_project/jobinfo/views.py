from django.shortcuts import render
from django.views import View

from jobinfo.models import (
    JobRecruiter,
    Company, JobSeeker, Position, appCycle, Application,
)


class JobRecruiterList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/jobRecruiter_list.html',
                      {'jobRecruiter_list': JobRecruiter.objects.all()}
                      )


class CompanyList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/company_list.html',
                      {'company_list': Company.objects.all()}
                      )


class JobSeekerList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/jobSeeker_list.html',
                      {'jobSeeker_list': JobSeeker.objects.all()}
                      )


class PositionList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/position_list.html',
                      {'position_list': Position.objects.all()}
                      )


class AppCycleList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/appCycle_list.html',
                      {'appCycle_list': appCycle.objects.all()}
                      )


class ApplicationList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/application_list.html',
                      {'application_list': Application.objects.all()}
                      )
