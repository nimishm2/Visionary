from django.shortcuts import redirect


def redirect_root_view(request):
    return redirect('jobinfo_company_list_urlpattern')
