from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import render, get_object_or_404, redirect
from django.views import View

from jobinfo.forms import JobRecruiterForm, CompanyForm, JobSeekerForm, PositionForm, AppCycleForm, ApplicationForm
from jobinfo.models import (
    JobRecruiter,
    Company, JobSeeker, Position, AppCycle, Application,
)
from jobinfo.utils import ObjectCreateMixin


class JobRecruiterList(View):
    page_kwarg = 'page'
    paginate_by = 25  # 25 instructors per page
    template_name = 'jobinfo/jobRecruiter_list.html'

    def get(self, request):
        jobRecruiters = JobRecruiter.objects.all()
        paginator = Paginator(
            jobRecruiters,
            self.paginate_by
        )
        page_number = request.GET.get(
            self.page_kwarg
        )
        try:
            page = paginator.page(page_number)
        except PageNotAnInteger:
            page = paginator.page(1)
        except EmptyPage:
            page = paginator.page(
                paginator.num_pages)
        if page.has_previous():
            prev_url = "?{pkw}={n}".format(
                pkw=self.page_kwarg,
                n=page.previous_page_number())
        else:
            prev_url = None
        if page.has_next():
            next_url = "?{pkw}={n}".format(
                pkw=self.page_kwarg,
                n=page.next_page_number())
        else:
            next_url = None
        context = {
            'is_paginated':
                page.has_other_pages(),
            'next_page_url': next_url,
            'paginator': paginator,
            'previous_page_url': prev_url,
            'jobRecruiter_list': page,
        }
        return render(
            request, self.template_name, context)


class JobRecruiterDetail(View):
    def get(self, request, pk):
        jobRecruiter = get_object_or_404(JobRecruiter, pk=pk)
        company_list = jobRecruiter.companies.all()
        return render(request,
                      'jobinfo/jobRecruiter_detail.html',
                      {'jobRecruiter': jobRecruiter, 'company_list': company_list}
                      )


class JobRecruiterUpdate(View):
    form_class = JobRecruiterForm
    model = JobRecruiter
    template_name = 'jobinfo/jobRecruiter_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        jobRecruiter = self.get_object(pk)
        context = {
            'form': self.form_class(
                instance=jobRecruiter),
            'jobRecruiter': jobRecruiter,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        jobRecruiter = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=jobRecruiter)
        if bound_form.is_valid():
            new_jobRecruiter = bound_form.save()
            return redirect(new_jobRecruiter)
        else:
            context = {
                'form': bound_form,
                'jobRecruiter': jobRecruiter,
            }
            return render(
                request,
                self.template_name,
                context)


class JobRecruiterDelete(View):
    def get(self, request, pk):
        jobRecruiter = self.get_object(pk)
        companies = jobRecruiter.companies.all()
        if companies.count() > 0:
            return render(
                request,
                'jobinfo/jobRecruiter_refuse_delete.html',
                {'jobRecruiter': jobRecruiter,
                 'companies': companies,
                 }
            )
        else:
            return render(
                request,
                'jobinfo/jobRecruiter_confirm_delete.html',
                {'jobRecruiter': jobRecruiter}
            )

    def get_object(self, pk):
        return get_object_or_404(
            JobRecruiter,
            pk=pk)

    def post(self, request, pk):
        jobRecruiter = self.get_object(pk)
        jobRecruiter.delete()
        return redirect('jobinfo_jobRecruiter_list_urlpattern')


class JobRecruiterCreate(ObjectCreateMixin, View):
    form_class = JobRecruiterForm
    template_name = 'jobinfo/jobRecruiter_form.html'


class CompanyList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/company_list.html',
                      {'company_list': Company.objects.all()}
                      )


class CompanyDetail(View):
    def get(self, request, pk):
        company = get_object_or_404(Company, pk=pk)
        company_appCycle = company.appCycle
        position = company.position
        jobRecruiter = company.jobRecruiter
        application_list = company.applications.all()
        return render(request,
                      'jobinfo/company_detail.html',
                      {'company': company, 'appCycle': company_appCycle, 'position': position,
                       'jobRecruiter': jobRecruiter,
                       'application_list': application_list}
                      )


class CompanyCreate(ObjectCreateMixin, View):
    form_class = CompanyForm
    template_name = 'jobinfo/company_form.html'


class CompanyUpdate(View):
    form_class = CompanyForm
    model = Company
    template_name = 'jobinfo/company_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        company = self.get_object(pk)
        context = {
            'form': self.form_class(instance=company),
            'company': company,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        company = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=company)
        if bound_form.is_valid():
            new_company = bound_form.save()
            return redirect(new_company)
        else:
            context = {
                'form': bound_form,
                'company': company,
            }
            return render(
                request,
                self.template_name,
                context)


class CompanyDelete(View):
    def get(self, request, pk):
        company = self.get_object(pk)
        applications = company.applications.all()
        if applications.count() > 0:
            return render(
                request,
                'jobinfo/company_refuse_delete.html',
                {'company': company,
                 'applications': applications,
                 }
            )
        else:
            return render(
                request,
                'jobinfo/company_confirm_delete.html',
                {'company': company}
            )

    def get_object(self, pk):
        return get_object_or_404(
            Company,
            pk=pk)

    def post(self, request, pk):
        company = self.get_object(pk)
        company.delete()
        return redirect('jobinfo_company_list_urlpattern')


class JobSeekerList(View):
    page_kwarg = 'page'
    paginate_by = 25
    template_name = 'jobinfo/jobSeeker_list.html'

    def get(self, request):
        jobSeekers = JobSeeker.objects.all()
        paginator = Paginator(
            jobSeekers,
            self.paginate_by
        )
        page_number = request.GET.get(
            self.page_kwarg
        )
        try:
            page = paginator.page(page_number)
        except PageNotAnInteger:
            page = paginator.page(1)
        except EmptyPage:
            page = paginator.page(
                paginator.num_pages)
        if page.has_previous():
            prev_url = "?{pkw}={n}".format(
                pkw=self.page_kwarg,
                n=page.previous_page_number())
        else:
            prev_url = None
        if page.has_next():
            next_url = "?{pkw}={n}".format(
                pkw=self.page_kwarg,
                n=page.next_page_number())
        else:
            next_url = None
        context = {
            'is_paginated':
                page.has_other_pages(),
            'next_page_url': next_url,
            'paginator': paginator,
            'previous_page_url': prev_url,
            'jobSeeker_list': page,
        }
        return render(
            request, self.template_name, context)


class JobSeekerDetail(View):
    def get(self, request, pk):
        jobSeeker = get_object_or_404(JobSeeker, pk=pk)
        application_list = jobSeeker.applications.all()
        return render(request,
                      'jobinfo/jobSeeker_detail.html',
                      {'jobSeeker': jobSeeker, 'application_list': application_list}
                      )


class JobSeekerCreate(ObjectCreateMixin, View):
    form_class = JobSeekerForm
    template_name = 'jobinfo/jobSeeker_form.html'


class JobSeekerUpdate(View):
    form_class = JobSeekerForm
    model = JobSeeker
    template_name = 'jobinfo/jobSeeker_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        jobSeeker = self.get_object(pk)
        context = {
            'form': self.form_class(instance=jobSeeker),
            'jobSeeker': jobSeeker,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        jobSeeker = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=jobSeeker)
        if bound_form.is_valid():
            new_jobSeeker = bound_form.save()
            return redirect(new_jobSeeker)
        else:
            context = {
                'form': bound_form,
                'jobSeeker': jobSeeker,
            }
            return render(
                request,
                self.template_name,
                context)


class JobSeekerDelete(View):
    def get(self, request, pk):
        jobSeeker = self.get_object(pk)
        applications = jobSeeker.applications.all()
        if applications.count() > 0:
            return render(
                request,
                'jobinfo/jobSeeker_refuse_delete.html',
                {'jobSeeker': jobSeeker,
                 'applications': applications,
                 }
            )
        else:
            return render(
                request,
                'jobinfo/jobSeeker_confirm_delete.html',
                {'jobSeeker': jobSeeker}
            )

    def get_object(self, pk):
        return get_object_or_404(
            JobSeeker,
            pk=pk)

    def post(self, request, pk):
        jobSeeker = self.get_object(pk)
        jobSeeker.delete()
        return redirect('jobinfo_jobSeeker_list_urlpattern')


class PositionList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/position_list.html',
                      {'position_list': Position.objects.all()}
                      )


class PositionDetail(View):
    def get(self, request, pk):
        position = get_object_or_404(Position, pk=pk)
        company_list = position.companies.all()
        return render(request, 'jobinfo/position_detail.html',
                      {'position': position, 'company_list': company_list}
                      )


class PositionCreate(ObjectCreateMixin, View):
    form_class = PositionForm
    template_name = 'jobinfo/position_form.html'


class PositionUpdate(View):
    form_class = PositionForm
    model = Position
    template_name = 'jobinfo/position_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        position = self.get_object(pk)
        context = {
            'form': self.form_class(instance=position),
            'position': position,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        position = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=position)
        if bound_form.is_valid():
            new_position = bound_form.save()
            return redirect(new_position)
        else:
            context = {
                'form': bound_form,
                'position': position,
            }
            return render(
                request,
                self.template_name,
                context)


class PositionDelete(View):
    def get(self, request, pk):
        position = self.get_object(pk)
        companies = position.companies.all()
        if companies.count() > 0:
            return render(
                request,
                'jobinfo/position_refuse_delete.html',
                {'position': position,
                 'companies': companies,
                 }
            )
        else:
            return render(
                request,
                'jobinfo/position_confirm_delete.html',
                {'position': position}
            )

    def get_object(self, pk):
        return get_object_or_404(
            Position,
            pk=pk)

    def post(self, request, pk):
        position = self.get_object(pk)
        position.delete()
        return redirect('jobinfo_position_list_urlpattern')


class AppCycleList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/appCycle_list.html',
                      {'appCycle_list': AppCycle.objects.all()}
                      )


class AppCycleDetail(View):
    def get(self, request, pk):
        appCycle = get_object_or_404(AppCycle, pk=pk)
        company_list = appCycle.companies.all()
        return render(request, 'jobinfo/appCycle_detail.html', {'appCycle': appCycle, 'company_list': company_list})


class AppCycleUpdate(View):
    form_class = AppCycleForm
    model = AppCycle
    template_name = 'jobinfo/appCycle_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        appCycle = self.get_object(pk)
        context = {
            'form': self.form_class(instance=appCycle),
            'appCycle': appCycle,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        appCycle = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=appCycle)
        if bound_form.is_valid():
            new_appCycle = bound_form.save()
            return redirect(new_appCycle)
        else:
            context = {
                'form': bound_form,
                'appCycle': appCycle,
            }
            return render(
                request,
                self.template_name,
                context)


class AppCycleDelete(View):
    def get(self, request, pk):
        appCycle = self.get_object(pk)
        companies = appCycle.companies.all()
        if companies.count() > 0:
            return render(
                request,
                'jobinfo/appCycle_refuse_delete.html',
                {'appCycle': appCycle,
                 'companies': companies,
                 }
            )
        else:
            return render(
                request,
                'jobinfo/appCycle_confirm_delete.html',
                {'appCycle': appCycle}
            )

    def get_object(self, pk):
        return get_object_or_404(
            AppCycle,
            pk=pk)

    def post(self, request, pk):
        appCycle = self.get_object(pk)
        appCycle.delete()
        return redirect('jobinfo_appCycle_list_urlpattern')


class AppCycleCreate(ObjectCreateMixin, View):
    form_class = AppCycleForm
    template_name = 'jobinfo/appCycle_form.html'


class ApplicationList(View):
    def get(self, request):
        return render(request,
                      'jobinfo/application_list.html',
                      {'application_list': Application.objects.all()}
                      )


class ApplicationDetail(View):
    def get(self, request, pk):
        application = get_object_or_404(Application, pk=pk)
        return render(request, 'jobinfo/application_detail.html',
                      {'application': application, 'jobSeeker': application.jobSeeker, 'company': application.company})


class ApplicationCreate(ObjectCreateMixin, View):
    form_class = ApplicationForm
    template_name = 'jobinfo/application_form.html'


class ApplicationUpdate(View):
    form_class = ApplicationForm
    model = Application
    template_name = 'jobinfo/application_form_update.html'

    def get_object(self, pk):
        return get_object_or_404(
            self.model,
            pk=pk)

    def get(self, request, pk):
        application = self.get_object(pk)
        context = {
            'form': self.form_class(instance=application),
            'application': application,
        }
        return render(
            request, self.template_name, context)

    def post(self, request, pk):
        application = self.get_object(pk)
        bound_form = self.form_class(
            request.POST, instance=application)
        if bound_form.is_valid():
            new_application = bound_form.save()
            return redirect(new_application)
        else:
            context = {
                'form': bound_form,
                'application': application,
            }
            return render(
                request,
                self.template_name,
                context)


class ApplicationDelete(View):

    def get(self, request, pk):
        application = self.get_object(pk)
        return render(
            request,
            'jobinfo/application_confirm_delete.html',
            {'application': application}
        )

    def get_object(self, pk):
        application = get_object_or_404(
            Application,
            pk=pk
        )
        return application

    def post(self, request, pk):
        application = self.get_object(pk)
        application.delete()
        return redirect('jobinfo_application_list_urlpattern')
