from django.shortcuts import render
from jobinfo.models import (
    JobRecruiter,
    Company, JobSeeker, Position, appCycle, Application,
)


def jobRecruiter_list_view(request):
    jobRecruiter_list = JobRecruiter.objects.all()
    return render(request, 'jobinfo/jobRecruiter_list.html', {'jobRecruiter_list': jobRecruiter_list})


def company_list_view(request):
    company_list = Company.objects.all()
    return render(request, 'jobinfo/company_list.html', {'company_list': company_list})


def jobSeeker_list_view(request):
    jobSeeker_list = JobSeeker.objects.all()
    return render(request, 'jobinfo/jobSeeker_list.html', {'jobSeeker_list': jobSeeker_list})


def position_list_view(request):
    position_list = Position.objects.all()
    return render(request, 'jobinfo/position_list.html', {'position_list': position_list})


def appCycle_list_view(request):
    appCycle_list = appCycle.objects.all()
    return render(request, 'jobinfo/appCycle_list.html', {'appCycle_list': appCycle_list})


def application_list_view(request):
    application_list = Application.objects.all()
    return render(request, 'jobinfo/application_list.html', {'application_list': application_list})