from django.contrib import admin
from django.urls import path
from jobinfo.views import (
    jobRecruiter_list_view,
    company_list_view,
    position_list_view,
    appCycle_list_view,
    jobSeeker_list_view,
    application_list_view,
)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('jobRecruiter/', jobRecruiter_list_view),
    path('company/', company_list_view),
    path('position/', position_list_view),
    path('appCycle/', appCycle_list_view),
    path('jobSeeker/', jobSeeker_list_view),
    path('application/', application_list_view),
]
