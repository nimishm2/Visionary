from django.urls import path

from jobinfo.views import (
    JobRecruiterList,
    CompanyList,
    JobSeekerList,
    PositionList,
    AppCycleList,
    ApplicationList, JobRecruiterDetail, CompanyDetail, JobSeekerDetail, AppCycleDetail, PositionDetail,
    ApplicationDetail,
)


urlpatterns = [
    path('jobRecruiter/', JobRecruiterList.as_view(),
         name='jobinfo_jobRecruiter_list_urlpattern'),
    path('jobRecruiter/<int:pk>/', JobRecruiterDetail.as_view(),
         name='jobinfo_jobRecruiter_detail_urlpattern'),
    path('company/', CompanyList.as_view(),
         name='jobinfo_company_list_urlpattern'),
    path('company/<int:pk>', CompanyDetail.as_view(),
         name='jobinfo_company_detail_urlpattern'),
    path('position/', PositionList.as_view(),
         name='jobinfo_position_list_urlpattern'),
    path('position/<int:pk>', PositionDetail.as_view(),
         name='jobinfo_position_detail_urlpattern'),
    path('appCycle/', AppCycleList.as_view(),
         name='jobinfo_appCycle_list_urlpattern'),
    path('appCycle/<int:pk>', AppCycleDetail.as_view(),
         name='jobinfo_appCycle_detail_urlpattern'),
    path('jobSeeker/', JobSeekerList.as_view(),
         name='jobinfo_jobSeeker_list_urlpattern'),
    path('jobSeeker/<int:pk>/', JobSeekerDetail.as_view(),
         name='jobinfo_jobSeeker_detail_urlpattern'),
    path('application/', ApplicationList.as_view(),
         name='jobinfo_application_list_urlpattern'),
    path('application/<int:pk>', ApplicationDetail.as_view(),
         name='jobinfo_application_detail_urlpattern'),
]
