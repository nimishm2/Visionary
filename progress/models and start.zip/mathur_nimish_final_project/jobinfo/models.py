from django.db import models


class Season(models.Model):
    season_id = models.AutoField(primary_key=True)
    season_sequence = models.IntegerField(unique=True)
    season_name = models.CharField(max_length=45, unique=True)


class Year(models.Model):
    year_id = models.AutoField(primary_key=True)
    year = models.IntegerField(unique=True)


class appCycle(models.Model):
    appCycle_id = models.AutoField(primary_key=True)
    year = models.ForeignKey(Year, related_name='appCycle', on_delete=models.PROTECT)
    season = models.ForeignKey(Season, related_name='appCycle', on_delete=models.PROTECT)


class Position(models.Model):
    position_id = models.AutoField(primary_key=True)
    position_number = models.CharField(max_length=20)
    position_name = models.CharField(max_length=255)


class JobRecruiter(models.Model):
    jobRecruiter_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    disambiguator = models.CharField(max_length=45, blank=True, default='')


class JobSeeker(models.Model):
    jobSeeker_id = models.AutoField(primary_key=True)
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)
    disambiguator = models.CharField(max_length=45, blank=True, default='')


class Company(models.Model):
    company_id = models.AutoField(primary_key=True)
    company_name = models.CharField(max_length=255)
    appCycle = models.ForeignKey(appCycle, related_name='company', on_delete=models.PROTECT)
    position = models.ForeignKey(Position, related_name='company', on_delete=models.PROTECT)
    jobRecruiter = models.ForeignKey(JobRecruiter, related_name='company', on_delete=models.PROTECT)


class Application(models.Model):
    application_id = models.AutoField(primary_key=True)
    jobSeeker = models.ForeignKey(JobSeeker, related_name='application', on_delete=models.PROTECT)
    company = models.ForeignKey(Company, related_name='application', on_delete=models.PROTECT)